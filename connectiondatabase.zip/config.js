module.exports = {
    // API reference URL
    apiUrl: "https://api.chat-api.com/instance288274",
    apiUrladitional: "https://api.chat-api.com/instance",
    // API token from your personal cabinet
    token: "smy3olccuhk4h604",

    llave: "ChatApiWhatsAppToken",

    tcipherKey: "8108B805CA8641258B30406B",

    cipherMethod: "des-ede3",

    decipherMethod: "des-ede3",

    tcTokenChatApi:"WErsrFILPoMY8G3f6uUBn9WZbmq2",

    uid:"WErsrFILPoMY8G3f6uUBn9WZbmq2"

}
