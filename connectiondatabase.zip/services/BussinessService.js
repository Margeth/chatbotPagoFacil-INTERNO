﻿const db = require('./db');
const goCrypto = require("crypto");
const { v4: uuidv4 } = require('uuid');
const config = require('../connectiondatabase/connection');
const goCompanyDao = require('../dao/companydao');

async function generateTokenService(tnEmpresaComercio){
    var lcTS="|";
    var company= await getCompanyData(tnEmpresaComercio);
    var lcCadenaBase1 = company.Empresa + lcTS + company.Pais + lcTS + company.Region + lcTS + company.Nombre.trim();
    var lcCadenaBase2 = company.RazonSocial.trim() + lcTS + String(company.NIT) + lcTS + company.Email;
    var lcCadenaBase3 = company.Empresa + lcTS + company.Serial + lcTS + company.Pais + lcTS + company.Region + lcTS + company.Nombre.trim();
    var lcCadenaBase4 = String(company.RazonSocial).trim() + lcTS + company.NIT.toString() + lcTS + String(company.Email).trim() + lcTS + String(company.tnTipoToken);
    let lcHash1 = goCrypto.createHash('sha256').update(lcCadenaBase1).digest('base64').trim();
    let lcHash2 = goCrypto.createHash('sha256').update(lcCadenaBase2).digest('base64').trim();
    let lcHash3 = goCrypto.createHash('sha256').update(lcCadenaBase3).digest('base64').trim();
    let lcHash4 = goCrypto.createHash('sha256').update(lcCadenaBase4).digest('base64').trim();

    let lcHash = lcHash1 + lcHash2 + lcHash3 + lcHash4;
    return lcHash;

}


function generateTokenSecret(){
    var loGUID = uuidv4();
//    var loGUID = new ActiveXObject("Scriptlet.TypeLib")
    var lcKey = loGUID.substring(2, 36);
    lcKey = lcKey.replace(/-/g,"");
    lcKey = lcKey.substring(0, 24);
    return lcKey;
}



async function updateKeyService(tnEmpresa) {
    var lcTokenService= await generateTokenService(tokenService.empresa);
    const coresult = await db.query(
        `UPDATE empresatoken
        SET TokenService=? WHERE Empresa=?`,
        [   
            lcTokenService,
            tnEmpresa
        ]
    );
    var lcmessage = 'Error actualizar los datos';

    if (coresult.affectedRows) {
      lcmessage = lcTokenService;
    }
  
    return lcmessage;
}


async function getAvailableInstancesInWhatsApp(){
    const loAvailableinstances = await goCompanyDao.getAvailableInstancesInWhatsApp();

    var laActiveInstanceList = [];
    var loResult ={};
    if (loAvailableinstances.length > 0) {

        for (var i = 0; i < loAvailableinstances.length; i++) {
            var laActiveInstance = {
                idinstancia: loAvailableinstances[i].InstanciaWhatsapp,
                numeroinstancia: loAvailableinstances[i].Instancia,
                tokeninstancia: loAvailableinstances[i].Token          
            }
            laActiveInstanceList.push( laActiveInstance );
        }
        loResult = {
            error: 0,
            status: 1,
            message: "Lista de instancias obtenidas correctamente.",
            messageMostrar: 1,
            messageSistema: "Obtencion de instancias exitosa",
            values: { 
                instanciasactivas:laActiveInstanceList
            } 
        }
    }
    else{

        loResult = {
            error: 1,
            status: 2,
            message: "No existe una instancia activa.",
            messageMostrar: 1,
            messageSistema: "No se pudo obtener instancias activas",
            values: { 
                instancia: "No existe una instancia activa"
            } 
            
        }
    }

    return loResult;
}

async function updateKeySecret(tnEmpresa) {
    var lcTokenService= await generateTokenSecret();
    const coresult = await db.query(
        `UPDATE EMPRESATOKEN
        SET TokenSecret=? WHERE Empresa=?`,
        [
            lcTokenService,
            tnEmpresa
        ]
    );
    let lcmessage = 'Error in updating programming language';

    if (coresult.affectedRows) {
      lcmessage = lcTokenService;
    }
  
    return lcmessage;
}

async function registerCompany(company){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(

        'INSERT INTO empresa(`Nombre`, `RazonSocial`, `Descripcion`, `Codigo`, `Token`, `Url_Icon`, `F_Edicion`, `Estado`, `ClienteIntegral`, `EstadoWebService`, `TipoDebug`, `ServerIP`, `ServerIpProxy`, `TigoDirecto`, `MaxCodigoCliente`, `EtiquetaCodigoFijo`, `Sistema`, `CadenaConexion`, `url_web`, `url_facebook`, `url_twitter`, `url_youtube`, `TipoEmpresa`, `Pais`, `region`, `direccion`, `email`, `telefono`, `FotoFrente`, `TipoComision`, `NIT`, `latitud`, `longitud`, `Email_TO`, `Email_CC`, `Email_CCO`, `Email_InformeError`, `Referencia_EmailError`, `Usr`, `UsrHora`, `UsrFecha`, `FotoDentro`, `Url_Imagen_Grande`, `EtiquetaAviso`, `EtiquetaTipoNota`, `EtiquetaDeuda`, `EtiquetaAvisoCompleta`, `EtiquetaItemPago`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            company.tcNombre,
            company.tcRazonSocial,
            company.tcDescripcion,
            company.tcCodigo,
            company.tcToken,
            null,
            lcdate,
            1,
            1,
            1,
            1,
            company.tcServerIP,
            null,
            null,
            1000,
            'Cliente',
            1,
            '',
            'sin direccion web',
            'sin direccion facebook',
            'sin direccion twitter',
            'sin direccion youtube',
            null,
            1, 
            1, 
            'sin direccion', 
            company.tcEmail,
            '628921251',
            '',
            0, 
            company.tcNit,
            '0',
            '0',
            null,
            null, 
            null, 
            '', 
            '',
            1, 
            lchour,
            lcdate,
            '', 
            '', 
            null, 
            null, 
            null, 
            null, 
            'Facturas'
        ]
    );
    var message='0';

    if(result.affectedRows){
        message='1';
    }

    return message;


}

async function registerTokenCompany(companySerial,serial,tokenType,tokenMethodCreation,title,tokenService,tokenSecret,urlCallBack,urlReturn,messajeClient){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(
        'INSERT INTO EMPRESATOKEN(Empresa,Serial,Estado,TipoToken,FechaCreacion,FechaLimite,MetodoCreacionToken,Titulo,TokenService,TokenSecret,UrlCallBack,UrlReturn,MensajeCliente) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
            companySerial,
            serial,
            1,
            tokenType,
            lcdate,
            '2022-06-02',
            tokenMethodCreation,
            title,
            tokenService,
            tokenSecret,
            urlCallBack,
            urlReturn,
            messajeClient,
        ]
    );
    let message='Error en registro de usuario';

    if(result.affectedRows){
        message='La empresa se registró correctamente';
    }

    return {message};


}


async function registerNewInstance(tcInstance,tcToken){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(
        'INSERT INTO INSTANCIAWHATSAPP(Instancia,Token,Estado,UsrFecha,UsrHora) VALUES (?,?,?,?,?)',
        [
            tcInstance,
            tcToken,
            1,
            lcdate,
            lchour
        ]
    );
    let message='Registro fallido de la nueva instancia en base de datos';

    if(result.affectedRows){
        message='Registro exitoso de la nueva instancia';
    }

    return {message};


}


async function deleteInstance(tcInstance){
    const coresult = await db.query(
        `UPDATE INSTANCIAWHATSAPP
        SET Estado=? WHERE Instancia=?`,
        [
            0,
            tcInstance
        ]
    );
    var lcmessage = 'Error en borrar instancias';

    if (coresult.affectedRows) {
      lcmessage = "Instancia borrada exitosamente";
    }
  
    return lcmessage;
}


async function getCompanyData(tnEmpresaComercio){
    var message='0';
    var i=0;
    const lnResult= await db.query(
        'SELECT * FROM EMPRESA WHERE Empresa=?',
        [
            tnEmpresaComercio
        ]
    );
    if(lnResult.length>0){
        message='1';

    }
    return lnResult[i];
}


function getCurrentDate(){
    let loDate = new Date();
    let lcday = ("0" + loDate.getDate()).slice(-2);
    let lcmonth = ("0" + (loDate.getMonth() + 1)).slice(-2);
    let lcyear = loDate.getFullYear();
    let lccurrentDate = lcyear + "-" + lcmonth + "-" + lcday;
    return lccurrentDate;
}

function getCurrentHour(){
    let loDate = new Date();
    let lchours = loDate.getHours();
    let lcminutes = loDate.getMinutes();
    let lcseconds = loDate.getSeconds();
    let lcCurrentHour=lchours + ":" + lcminutes + ":" + lcseconds;
    return lcCurrentHour;
}

async function getLastBussiness(){
    const lnResult= await db.query(
        'SELECT Empresa FROM EMPRESA ORDER BY Empresa DESC LIMIT 1'
    );
    return lnResult;


}

async function searchConversationListByIdChat(chatId){
    var laConversationsFounded = null;
    const loResult = await db.query(
        'SELECT DISTINCT CONVERSACION.Conversacion as id,CONVERSACION.TipoConversacion as tipo,CONVERSACION.UsrFecha as fecha FROM CONVERSACION, CHATAGENTE, CHATAGENTECONVERSACION ' +
        'WHERE CHATAGENTE.Chat=? ' +
        'AND CHATAGENTECONVERSACION.ChatempresaAgente = CHATAGENTE.ChatAgente ' +
        'AND CONVERSACION.Conversacion = CHATAGENTECONVERSACION.Conversacion',
        [
            chatId,
        ]
    );
    if (loResult.length > 0) {
        laConversationsFounded = loResult;
    }
    return laConversationsFounded;
}


async function searchMessagesByConversationId(tcConversationId){
    var laConversationsFounded = null;
    const loResult = await db.query(
        'SELECT Mensaje as id,Recibido as recibido ,mensajeWhatsApp as idwap, ContenidoMensaje as contenido, mensajeReenviado as menreen, isBotAutomatico as bot ' +
        'FROM MENSAJE '+
        'WHERE Conversacion=?', 
        [
            tcConversationId,
        ]
    );
    if (loResult.length > 0) {
        laConversationsFounded = loResult;
    }
    return laConversationsFounded;
}

/*
async function searchConversationListByIdChat(chatId){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const loResult= await db.query(
        'SELECT conversacion.Conversacion,conversacion.TipoConversacion,conversacion.UsrFecha,conversacion.UsrHora '+
        'FROM conversacion, chatagenteconversacion, chatagente '+
        'WHERE chatAgente.Chat=?'+
        'AND chatAgente.ChatAgente=('+
        'SELECT ChatAgente FROM chatagenteconversacion '+
        'ORDER BY column_name ASC '+
        'LIMIT 1;'
        +')',
        [
            agentId,
            chatId,
            1,
            lcdate,
            lchour
        ]
    );
    let message=0;

    if(loResult.affectedRows){
        message=1;
    }

    return message;
}
*/


async function getCompanies(){
    const rows = await db.query(
        'SELECT * FROM EMPRESA'
    );
    return rows;
}

function generateCommerceID(){
    return goCrypto.createHash('sha256').update("1").digest('base64').trim();

}


async function modifyInstanceToAvailable(tnInstanceNumber){
    lnSuccessfulUpdateInstance= await goCompanyDao.putInstanceAvailable(tnInstanceNumber);
}

module.exports={
    generateTokenService,
    generateTokenSecret,
    updateKeyService,
    updateKeySecret,
    registerCompany,
    registerTokenCompany,
    getLastBussiness,
    getCompanies,
    generateCommerceID,
    getCompanyData,
    registerNewInstance,
    deleteInstance,
    modifyInstanceToAvailable,
    searchConversationListByIdChat,
    searchMessagesByConversationId,
    getAvailableInstancesInWhatsApp
}
