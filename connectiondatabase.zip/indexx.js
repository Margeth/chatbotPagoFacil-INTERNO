const config = require("./config");
//const token = config.token, apiUrl = config.apiUrl;
const app = require('express')();
var request = require('request');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const jwt = require('jsonwebtoken');
const express = require('express');
const goPad = require('pad');
const Key = require('./Model/Key');
const goMessage = require('./Model/Message');
const goCrypto = require("crypto");

const cryptoJS = require("crypto-js");
const messageService= require("./services/MessagesService");
const Message = require("./Model/Message");
const e = require("express");
app.use(bodyParser.json());
const goSecurityService= require("./services/SecurityService");
const rutasProtegidas = express.Router();
//const goKey = new Key("des-ede3", "des-ede3", "8108B805CA8641258B30406B");
const goKey = new Key(config.cipherMethod, config.decipherMethod, config.tcipherKey);
const messagesRouter= require('./routes/messageroutes');
const authenticationRouter= require('./routes/Authenticationroutes');
const bussinessRouter=require('./routes/Bussinessroutes');
//const empresaRouter=require('./routes/rutasEmpresa');


const port = process.env.PORT || 5002;


//app.use(express.static(path.join(__dirname+"")));
app.use(express.static(__dirname+""))
app.use(bodyParser.urlencoded({
    extended:true
}));



//______________________________________
app.use('/mensajes',messagesRouter.router);
app.use('/authentication',authenticationRouter.router);
app.use('/bussiness',bussinessRouter.router);
//app.use('/bussiness',empresaRouter.router);
//________________________________


app.listen(port,function () {
    console.log('Listening on port',port);
});




app.set('llave',config.llave);



process.on('unhandledRejection', err => {
    console.log(err)
});

app.post('/', async function (req, res) {
    console.log(req.body);
    await messageService.verifyUser(req, res);
    await messageService.verifyChatGeneral(req, res);
    await messageService.registerReceivedMessageGeneral(req, res);    
});



app.get('/linkprueba', async function(request,res){
    const loResult ={
        error: 0,
        status: 1,
        message: "El contacto fue enviado con exito.",
        messageMostrar: 1,
        messageSistema: "",
        values: { message: "Contacto enviado exitosamente" }
    };
    res.json(loResult);

})







app.post('/jwtexample', async function(req,res){
    const text = await goSecurityService.encrypt3DES(req.body.text, goKey.getKey());    
    /*const message = await goSecurityService.encrypt3DES(req.body.message, goKey.getKey()); 
    const chatId = await goSecurityService.encrypt3DES(req.body.ChatId, goKey.getKey());
    const user = await goSecurityService.encrypt3DES(req.body.usuario, goKey.getKey());
    const empresa = await goSecurityService.encrypt3DES(req.body.empresa, goKey.getKey());          
    */
    res.json(
        {
            dato: text
        });

});



