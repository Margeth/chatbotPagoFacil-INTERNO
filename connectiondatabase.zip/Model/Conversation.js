class Conversation{

    constructor(idConversation,typeConversation,dateRegister){

        this.idConversation=idConversation;
        this.typeConversation=typeConversation;
        this.dateRegister=dateRegister;
    }
}

module.exports = Conversation;