const express = require('express');
const messageService=require('../services/MessagesService');
const bussinessService=require('../services/BussinessService');
const config = require("./../config");
const router= express.Router();
const goSecurityService= require('../services/SecurityService');
const companydao= require('../dao/companydao');
const tokenAPI= config.uid;
const authenticationRouter= require('../routes/Authenticationroutes');
const Key = require('../Model/Key');
const Message = require("../Model/Message");
const Conversation = require('../Model/Conversation');
const MessageConversation = require('../Model/Messageconversation');
const goKey = new Key(config.cipherMethod, config.decipherMethod, config.tcipherKey);



router.post('/registrarEmpresa',authenticationRouter.rutasProtegidas, async function registerCompany(req, res) {
    var lcmessage = await bussinessService.registerCompany(req.body);
    if(lcmessage==='1'){
        let loLastCompany= await bussinessService.getLastBussiness();
        var lctokenSecret = await bussinessService.generateTokenSecret();
        var lctokenService = await bussinessService.generateTokenService();
        var lccommerceID = await bussinessService.generateCommerceID();    
        var lcmessageTokenRegistered = await bussinessService.registerTokenCompany(loLastCompany[0].Empresa, 1, 'TipoToken1', 'MetodoDeCreacion', 'NOmbreEmpresa', lctokenService, lctokenSecret, 'http:/pagoFacilBolivia.com', 'http://pagoFacilBolivia.com', 'Buenas tardes');
        const loKey = {
            error: 0,
            status: 1,
            message: "Registro exitoso de empresa, Generación de licencias correctas",
            messageMostrar: 1,
            messageSistema: lcmessageTokenRegistered,
            values: {         
                tokenSecret: lctokenSecret,
                tokenService: lctokenService,
                CommerceID: lccommerceID
         }
        };
        res.json(loKey);

    }
    else{
        const loKey = {
            error: 1,
            status: 1,
            message: "Ocurrio un error en el registro de la empresa",
            messageMostrar: 1,
            messageSistema: lcmessageTokenRegistered,
            values: {         
                mensaje:"Ocurrio un error en el registro"
         }
        };
        res.json(loKey);

    }
//    var message = await messageService.registerCompany(req.body);
});

router.post('/generartokensempresa',authenticationRouter.rutasProtegidas, async function registerCompany(req, res) {
    try{
        var lnEmpresaCommerceId= goSecurityService.descrypt3DES(req.body.tnEmpresaComercio, goKey.getKey());;
        var lctokenSecret = await bussinessService.generateTokenSecret();
        var lctokenService = await bussinessService.generateTokenService(lnEmpresaCommerceId);
        var company= await bussinessService.getCompanyData(lnEmpresaCommerceId);
        var lcmessageTokenRegistered = await bussinessService.registerTokenCompany(company.Empresa, 1, 'Service', 'generateBussinessKeys', company.Nombre , lctokenService, lctokenSecret, company.direccion, company.email, 'Buenas tardes');
        const loKey = {
            error: 0,
            status: 1,
            message: "Generación de licencias correctas",
            messageMostrar: 1,
            messageSistema: "Generación de llaves realizado con exito",
            values: {
                tokenSecret: lctokenSecret,
                tokenService: lctokenService
            }
        };
    
        res.json(loKey);
    
    }
    catch(exception){
        res.json(messageService.responseMessageExceptionActivated());

    }
//    res.json({message:lctokenSecret});
});


router.post('/actualizarTokenSecreto',authenticationRouter.rutasProtegidas,async function(req,res,next){
    try {
        var lnEmpresaId= goSecurityService.descrypt3DES(req.body.tnEmpresa, goKey.getKey());
        let lcMessageService = await bussinessService.updateKeySecret(lnEmpresaId);
        const loKey = {
            error: 0,
            status: 0,
            message: "La actualización fue realizada con exito.",
            messageMostrar: 1,
            messageSistema: "",
            values: { TokenSecret: lcMessageService }
        };
        res.json(loKey);

    }catch(err){
        const loKey = {
            error: 1,
            status: 1,
            message: "Ocurrio un error con la actualización",
            messageMostrar: 0,
            messageSistema: "",
            values: { key: "Llave invalida" }
        };
        next(loKey);
    }
});

router.post('/actualizarTokenServicio',authenticationRouter.rutasProtegidas,async function(req,res,next){
    try {
        var lnEmpresaId= goSecurityService.descrypt3DES(req.body.tnEmpresa, goKey.getKey());;
        let lcMessageService = await bussinessService.updateKeyService(lnEmpresaId);
        const loKey = {
            error: 0,
            status: 1,
            message: "La actualización fue realizada con exito.",
            messageMostrar: 1,
            messageSistema: "",
            values: { TokenSecret: lcMessageService }
        };
        res.json(loKey);

    }catch(err){
        const loKey = {
            error: 1,
            status: 1,
            message: "Ocurrio un error con la actualización",
            messageMostrar: 0,
            messageSistema: "",
            values: { mensaje: "Llave invalida" }
        };
        res.json(loKey);
    }

});

router.get('/addInstance',authenticationRouter.rutasProtegidas,async function(request,res){
    const  loparams =
    {
        "uid": tokenAPI,
        "type": "whatsapp"
    }
    const loResponse = await messageService.apiChatApiInstancePost('newInstance', loparams);
    var loResult = null;
    if (loResponse.result.status === 'created') {
        const lcMessage = await bussinessService.registerNewInstance(loResponse.result.instance.id, loResponse.result.instance.token);
        loResult = {
            error: 0,
            status: 1,
            message: "Exito en crear la nueva instancia.",
            messageMostrar: 1,
            messageSistema: "La nueva instancia se creó correctamente",
            values: { mensaje: lcMessage }
        };
    }
    else {
        loResult = {
            error: 0,
            status: 1,
            message: "Error en crear la nueva instancia.",
            messageMostrar: 1,
            messageSistema: "La nueva instancia no pudo crear correctamente",
            values: { mensaje: "Instancia no fue creada correctamente" }
        };

    }
    res.json(loResult);
});

router.get('/listaInstancias', authenticationRouter.rutasProtegidas, async function (request, res) {
    const loResponse = await messageService.apiChatApiInstanceGet();
    var loResult = {
        error: 0,
        status: 1,
        message: "Lista de instancias obtenida correctamente.",
        messageMostrar: 1,
        messageSistema: "Lista de instancias se obtuvo exitosamente",
        values: { values: loResponse }
            };
    res.json(loResult);
});



router.post('/deleteInstance', authenticationRouter.rutasProtegidas, async function (request, res) {
    try{
        const lobdata = request.body;
        const lcInstanceNumber = goSecurityService.descrypt3DES(lobdata.tcInstance, goKey.getKey());
        const loparams =
        {
            "uid": tokenAPI,
            "instanceId": lcInstanceNumber.replace(/\0.*$/g, '')
        }
        var lcMessage = "La instancia no se eliminó correctamente";
        const loResponse = await messageService.apiChatApiInstancePost('deleteInstance', loparams);
        if (loResponse.result === 'deleted') {
            lcMessage = bussinessService.deleteInstance(lcInstanceNumber.replace(/\0.*$/g, ''));
            var loResult = {
                error: 0,
                status: 1,
                message: "Exito en borrar la nueva instancia.",
                messageMostrar: 1,
                messageSistema: "La instancia se borro correctamente",
                values: { mensaje: lcMessage }
            };
        }
        else {
            var loResult = {
                error: 0,
                status: 1,
                message: "Fallo en borrar la nueva instancia.",
                messageMostrar: 1,
                messageSistema: "La instancia no se borro correctamente",
                values: { mensaje: lcMessage }
            };
        }
        res.json(loResult);
    
    }
    catch(exception){
        res.json(messageService.responseMessageExceptionActivated());

    }
});


router.get('/getqruser', authenticationRouter.rutasProtegidas, async function(req,res){
    const loinstanceAvailable= await companydao.searchAvailableInstancesInWhatsApp();
    const loResponse = await messageService.apiChatApiDialogQRCode(res,loinstanceAvailable.Instancia, loinstanceAvailable.Token);
});


router.post('/cerrarSesion', authenticationRouter.rutasProtegidas, async function (request, res) {
    try{
        const lobdata = request.body;
        const lcInstanceNumber = goSecurityService.descrypt3DES(lobdata.tcInstance, goKey.getKey()); 
        var loInstanceAndUsername = await messageService.searchInstanceByIdUserWhatsApp(lcInstanceNumber.replace(/\0.*$/g, ''));
        const loResponse = await messageService.apiChatApiLogoutSystem('logout', loInstanceAndUsername.instancia, loInstanceAndUsername.token);
        var loResult=null;
        if(typeof(loResponse.result)==='undefined'){
            loResult = {
                error: 1,
                status: 2,
                message: "Ocurrio un error en el cierre de sesión.",
                messageMostrar: 1,
                messageSistema: "Fallo al cerrar sesión",
                values: { values: loResponse }
            };    
        }
        else{
            loResult = {
                error: 0,
                status: 1,
                message: "Exito en cerrar sesión.",
                messageMostrar: 1,
                messageSistema: "Se cerró la sesión correctamente",
                values: { values: loResponse }
            };    
    
    
        }
        res.json(loResult);    
    }
    catch(exception){
        res.json(messageService.responseMessageExceptionActivated());

    }
});



router.post('/listaConversacionesByIdChat', authenticationRouter.rutasProtegidas, async function (request, res) {
    const loData = request.body;
    const lcChat = goSecurityService.descrypt3DES(loData.tcChatId, goKey.getKey());
    const laConversationsList= await bussinessService.searchConversationListByIdChat(lcChat.replace(/\0.*$/g, ''));
    var loResult=null;
    var laConversationsArray=[];
    if(typeof laConversationsList != 'undefined' ){
        for( var i = 0; i < laConversationsList.length; i++){
            var lcIdConversation = goSecurityService.encrypt3DES(laConversationsList[i].id, goKey.getKey());
            var lcTypeConversation = goSecurityService.encrypt3DES(laConversationsList[i].tipo, goKey.getKey());
            var lcFecha = goSecurityService.encrypt3DES(laConversationsList[i].fecha, goKey.getKey());
            const loConversation = new Conversation(lcIdConversation, lcTypeConversation, lcFecha);
            laConversationsArray.push(loConversation);
        }
        loResult = {
            error: 0,
            status: 1,
            message: "Exito en crear la nueva instancia.",
            messageMostrar: 1,
            messageSistema: "La nueva instancia se creó correctamente",
            values: { values: laConversationsArray }
        };
    }
    else{
            loResult = {
                error: 1,
                status: 2,
                message: "No se encontraron conversaciones.",
                messageMostrar: 1,
                messageSistema: "No se encontraron conversaciones existentes",
                values: { mensaje: "No existen conversaciones existentes" }

        }
    }
    res.json(loResult);
});


router.post('/listMessagesByConversationId', authenticationRouter.rutasProtegidas, async function (request, res) {
    try{
        const loData = request.body;
        const lcIdConversation = goSecurityService.descrypt3DES(loData.tnConversationId, goKey.getKey());
        const laMessageListConversations= await bussinessService.searchMessagesByConversationId(lcIdConversation.replace(/\0.*$/g, ''));
        var loResult=null;
        var laMessageListConversationsArray=[];
        if(typeof laMessageListConversations != 'undefined' ){
            for( var i = 0; i < laMessageListConversations.length; i++){
                var lnMessageId = goSecurityService.encrypt3DES(laMessageListConversations[i].id, goKey.getKey());
                var lcReceived = goSecurityService.encrypt3DES(laMessageListConversations[i].recibido+"1", goKey.getKey());
                var lcWhatsAppId = goSecurityService.encrypt3DES(laMessageListConversations[i].idwap, goKey.getKey());
                var lcContentMessage = goSecurityService.encrypt3DES(laMessageListConversations[i].contenido, goKey.getKey());
                var lcRewardedMessage = goSecurityService.encrypt3DES(laMessageListConversations[i].menreen, goKey.getKey());
                var lcAutomaticBot= goSecurityService.encrypt3DES(laMessageListConversations[i].bot, goKey.getKey());
                const loConversation = new MessageConversation(lnMessageId,lcReceived,lcWhatsAppId,lcContentMessage,lcRewardedMessage,lcAutomaticBot);
                laMessageListConversationsArray.push(loConversation);
            }
            loResult = {
                error: 0,
                status: 1,
                message: "Exito en crear la nueva instancia.",
                messageMostrar: 1,
                messageSistema: "La nueva instancia se creó correctamente",
                values: { values: laMessageListConversationsArray }
            };
        }
        else{
            loResult = {
                error: 1,
                status: 2,
                message: "No se encontraron conversaciones.",
                messageMostrar: 1,
                messageSistema: "No se encontraron conversaciones existentes",
                values: { mensaje: "No existen conversaciones existentes" }
    
            }
        }
        res.json(loResult);
    
    }
    catch(exception){
        const loResult = {
            error: 1,
            status: 2,
            message: "Operación fallida ",
            messageMostrar: 1,
            messageSistema: "",
            values: { message: "Revise los parametros de envío en la solicitud" }
        };
        res.json(loResult);
    }
});


router.get('/getInstanceInformation', authenticationRouter.rutasProtegidas, async function(req,res){
    const loInformationAvailableInstances = await bussinessService.getAvailableInstancesInWhatsApp(); 
    res.json( loInformationAvailableInstances );
});


module.exports={
    router
}
