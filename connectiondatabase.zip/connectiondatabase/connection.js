const env = process.env;

const connectiondatabase={
/*    db:{
        host: '107.190.132.210',
        user: 'syscoopc_wapbot',
        password: '5kCem=4Z_L22',
        database: 'syscoopc_WhatsApp'
    }*/
  
  /*
    db:{
        host: 'localhost',
        user: 'whatsapp_waapise',
        password: 'Wha?#scApinjs',
        database: 'whatsapp_nodejsbot'
    }
    */

/*
    db:{
        host: 'whatsappfacildb.cc9cfpuk4ash.us-east-1.rds.amazonaws.com.',
        user: 'pagofaciluser',
        password: 'ZX1iqpD86abqfOcUgFaA',
        database: 'whatsappfacil'
    }
    */
     db:{
        host: 'database-1.cc9cfpuk4ash.us-east-1.rds.amazonaws.com',
        user: 'admin',
        password: 'brDTIOQHvaAhaLn48eaA',
        database: 'PagoFacil_WhatsApp'
    }
    



}


module.exports = connectiondatabase;