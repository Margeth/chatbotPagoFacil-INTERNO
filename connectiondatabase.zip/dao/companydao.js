﻿const db= require('../services/db');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');

async function searchCompanyByIdChat(chatId){
    var lnidChatFounded = 0;
    const result= await db.query(
        'SELECT Empresa FROM chat WHERE CHAT=?',
        [
            chatId
        ]
    );
    if(result.length>0){
        lnidChatFounded=result[0].Empresa;

    }
    return lnidChatFounded;
}


async function changeAgent(empresa,agente,conversacion){
    var lnIdAsignAgent= await searchLastActiveAgentToConversation(conversacion);
    if(lnasigAgentToConversation!=0){
        var lncloseConversation= await closeConversation(lnIdAsignAgent);
    }
    var lnasigAgentToConversation = await asignAgentToConversation(conversacion, empresa, agente);
    return lnasigAgentToConversation;
}


async function searchCompany(){
    


}

async function asignAgentToConversation(conversation,empresa,agente){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(
        'INSERT INTO asignaragenteconversacion(Conversacion,Empresa,Agente,UsrHora,UsrFecha,Estado) VALUES (?,?,?,?,?,?)',
        [
            conversation,
            empresa,
            agente,
            lchour,
            lcdate,
            1
        ]
    );
    let message='Error en registro de conversacion';

    if(result.affectedRows){
        message='Conversacion se registró correctamente';
    }

    return {message};
}

async function closeConversation(conversacion) {
    const result = await db.query(
        `UPDATE asignaragenteconversacion
        SET Estado=? WHERE AsignarAgenteConversacion=?`,
        [   
            0,
            conversacion
        ]
    );
    let message = 'Error in updating programming language';

    if (result.affectedRows) {
      message = 'Programming language updated successfully';
    }
  
    return {message};
}


async function putInstanceAvailable(tnInstanceNumber) {
    const result = await db.query(
        `UPDATE INSTANCIAWHATSAPP
        SET Estado=? WHERE Instancia=?`,
        [   
            1,
            tnInstanceNumber
        ]
    );
    var lnModifySuccessful= 0;

    if (result.affectedRows) {
      lnModifySuccessful=1;
    }
  
    return lnModifySuccessful;
}



async function registerConversation(conversation){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(
        'INSERT INTO CONVERSACION(TipoConversacion,Estado,UsrFecha,UserHora,UsrFechaExpiracion,UsrHoraExpiracion,Chat) VALUES (?,?,?,?,?,?,?)',
        [
            conversation.TipoConversacion,
            1,
            lcdate,
            lchour,
            lcdate,
            lchour,
            conversation.Chat,
        ]
    );
    let message=0;

    if(result.affectedRows){
        message=1;
    }

    return message;

}


async function queryToUser(userWhatsApp){
    var message='0';
    const result= await db.query(
        'SELECT * FROM USUARIO WHERE UsuarioWhatsApp=?',
        [
            userWhatsApp
        ]
    );
    if(result.length>0){
        message='1';

    }
    return message;

}


async function searchUser(userWhatsApp){
    const loResult= await db.query(
        'SELECT Usuario FROM USUARIO WHERE UsuarioWhatsApp=?',
        [
            userWhatsApp
        ]
    );
    return loResult[0].Usuario;

}


async function searchConversationByChatAgentId(chatAgentId){
    var lnIdAsignAgent=0;
    const loresult= await db.query(
        'SELECT conversacion.Conversacion as id '+
        'FROM CHATAGENTECONVERSACION, CONVERSACION, CHATAGENTE '+
        'WHERE CONVERSACION.Conversacion = chatagenteconversacion.Conversacion '+
        'AND CHATAGENTE.ChatAgente = chatagenteconversacion.ChatempresaAgente '+
        'AND chatagenteconversacion.Estado=? '+
        'AND CHATAGENTE.ChatAgente=? ',
        [
            1,
            chatAgentId
        ]   
    );
    if(loresult.length>0){
        lnIdAsignAgent=loresult[0].id; 

    }
    return lnIdAsignAgent;
}


async function registerAgentChat(agentId,chatId){
    let lcdate= getCurrentDate();
    let lchour= getCurrentHour();
    const result= await db.query(
        'INSERT INTO chatagente(Agente,Chat,Estado,UsrFecha,UsrHora) VALUES (?,?,?,?,?)',
        [
            agentId,
            chatId,
            1,
            lcdate,
            lchour,
        ]
    );
    let message='Error en registro de usuario';

    if(result.affectedRows){
        message='Usuario se registró correctamente';
    }

    return {message};
}


async function verifyAgentChat(idChat){
    const result= await db.query(
        'SELECT * FROM chatagente WHERE Chat=?',
        [
            idChat
        ]
    );
    if(result.length>0){
        lcmessage='1';

    }
    else{
        lcmessage='0';

    }
    return lcmessage;
}

async function searchAvailableInstancesInWhatsApp(){
    var quantity= null;
    const loResult= await db.query(
        'SELECT InstanciaWhatsapp, Instancia, Token '+
        'FROM INSTANCIAWHATSAPP WHERE Estado=?',
        [
            1
        ]   
    );
//    console.log("La instancia es "+loResult[0].Instancia+" y el token es "+loResult[0].Token);
    if(loResult.length>0){
        quantity=loResult[0]; 
    }
    else{
        quantity={
            InstanciaWhatsapp:0
        }
    }
    return quantity;
}

async function getAvailableInstancesInWhatsApp(){

    const loResult= await db.query(
        'SELECT InstanciaWhatsapp, Instancia, Token '+
        'FROM INSTANCIAWHATSAPP WHERE Estado=?',
        [
            1
        ]   
    );
//    console.log("La instancia es "+loResult[0].Instancia+" y el token es "+loResult[0].Token);
    return loResult;
}


module.exports={
    queryToUser,
    registerConversation,
    searchConversationByChatAgentId,
    changeAgent,
    searchAvailableInstancesInWhatsApp,
    putInstanceAvailable,
    getAvailableInstancesInWhatsApp

}