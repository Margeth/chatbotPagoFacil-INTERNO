/*var ChatApiSdk = require('chat_api_sdk');

var defaultClient = ChatApiSdk.ApiClient.instance;
// Configure API key authorization: instanceId
var instanceId = defaultClient.authentications['instanceId'];
instanceId.apiKey = "NYkh9Bg4TKS8oD1srnRd5lsxsk82"
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
instanceId.apiKeyPrefix['instanceId'] = "Token"
// Configure API key authorization: token
var token = defaultClient.authentications['token'];
token.apiKey = "NYkh9Bg4TKS8oD1srnRd5lsxsk82"
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
token.apiKeyPrefix['token'] = "Token"

var api = new ChatApiSdk.Class1InstanceApi()
var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
api.expiry(callback);*/